/*
 * forbindelse mellem DB og MedlemGui's btnSlet .
 * G�r det muligt at slette et Medlem.
 */
package dlayer;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class DeleteBookingSQL {	
	
	// metode til sletning af specifikt medlem
	public static void deleteBooking() {
		try {
			// pop-up; gemmer det indtastede int i en variabel
			int vari = Integer.parseInt(JOptionPane.showInputDialog("Insert booking/meeting date"
					+ " to delete it", "bookingID"));
			
			// sql statement der skal udf�res
			  String sql = "DELETE spillerstatistik, spiller "
			   + "FROM spillerstatistik, spiller "
			   + "WHERE spillerstatistik.idspillerstatistik = spiller.idspiller "
			   + "AND spiller.idspiller = " + vari;
			 
			// kalder DBConnections metode - forbinder med DB.
			  Connection conn = DBConnection.getConnection();
			  
			// opretter og udf�rer sql statement objekt.
			  Statement statement = conn.createStatement();
			  statement.execute(sql);
			  
			// pop-up; fort�ller, at det specifikke medlem er slettet
			  JOptionPane.showMessageDialog(null, "The booking/meeting with the ID " + vari + " has been deleted");
			  }
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}