package dlayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class FakturaSQL
{
	// Metode der tilf�jer regning.
	public static void addFaktura(String fornavn, String efternavn, String tlf, String Email, String vej,
			String postnummer, String by, String cvr, String virkNavn, String produkt, String beskrivelse,
			int antal, String valuta, int enhedspris, int eksMomsSum, int inkMomsSum, String dato,
			String betalingsfrist, boolean betalt) throws SQLException 
	{

		try  {
			// Opretter forbindelse til DB og s�tter sql statement ind i PreparedStatement
			Connection conn = DBConnection.getConnection();
			PreparedStatement prepareStatement = null;
			prepareStatement = conn.prepareStatement("INSERT INTO `finances`.`faktura` (`fornavn`, `efternavn`, "
					+ "`tlf`, `email`, `vej`, `postnummer`, `by`, `cvr`, `virksomhedsnavn`, "
					+ "`produkt`, `beskrivelse`, `antal`, `valuta`, `enhedspris`, `ialtEksklMoms`, "
					+ "`ialtInklMoms`, `dato`, `betalingsfrist`, `paid`)"
					+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");     
			
			
			
			



			//leverand�r, regningsdato, betalt, betlingsfrist, bilagsnr(auto increment), valuta,
			// beskrvelse, udgfskategori, momssats, eks. moms , ink moms(auto), 


			// Tilf�jer til DB med v�rdierne fra OpretMedlemGui
			prepareStatement.setString(1, fornavn );
			prepareStatement.setString(2, efternavn );
			prepareStatement.setString(3, tlf);
			prepareStatement.setString(4, Email);
			prepareStatement.setString(5, vej);
			prepareStatement.setString(6, postnummer);
			prepareStatement.setString(7, by);
			prepareStatement.setString(8,  cvr);
			prepareStatement.setString(9, virkNavn);
			prepareStatement.setString(10, produkt);
			prepareStatement.setString(11, beskrivelse);
			prepareStatement.setInt(12, antal);
			prepareStatement.setString(13, valuta);
			prepareStatement.setInt(14, enhedspris);
			prepareStatement.setInt(15, eksMomsSum);
			prepareStatement.setInt(16, inkMomsSum);
			prepareStatement.setString(17, dato);
			prepareStatement.setString(18, betalingsfrist);
			prepareStatement.setBoolean(19, betalt);
			
			
		
			

			prepareStatement.executeUpdate();


		}
		catch (SQLException e)
		{
			System.err.println(e);
		}
	}


}