/*
 * Forbindelse mellem DB og Medlem objekt(model.Medlem)
 * Muligg�rer visning af medlem (Medlemoversigt)
 * Mulig�rer opdatering af medlemsstatistik
 */


package dlayer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Medlem;

 public class MedlemOversigtSQL 
 {
  // Metoden medlem(), returnerer en ArrayList af Medlem
  public static ArrayList<Medlem> medlem() throws SQLException {

    //Opretter en ArrayListe kaldet medl, der indeholder Medlem objektet.
    ArrayList<Medlem> medl = new ArrayList<>();
       
    // sql statement
    String sql = "SELECT * FROM spiller";
               
    // kalder vores DBConnection klasse, og metoden deri, for at forbinde med DB.
    Connection conn = DBConnection.getConnection();
    
    // opretter og execute'er sql statement objekt.
    Statement statement = conn.createStatement();
        statement.execute(sql);

        // ResultSet objektet indeholder output af data fra sql'ens statement
    ResultSet results = statement.getResultSet();
    while(results.next()) {
     
     int idspiller= results.getInt("idspiller");
     String fornavn =  results.getString ("fornavn");
     String efternavn = results.getString("efternavn");
     int cpr = results.getInt("cpr");
     String email = results.getString("email");
     int tlf = results.getInt("tlf");
     String ben = results.getString("ben");
     String toejstoerrelse = results.getString("toejstoerrelse");
     String land = results.getString("land");
     int idhold = results.getInt("idhold");
     
     // Opretter en ny instans(objekt) af Medlem klassen og tilf�jer data til den(medl).
     Medlem medlem = new Medlem(idspiller,fornavn,efternavn,cpr,email,tlf,ben,toejstoerrelse,land,idhold);
     medl.add(medlem);       
    }
    // returner ArrayListen og "lukker" vores ResultSet og Statement (frig�rer resourcer)
    results.close();
    statement.close();
    return medl;
    
  }
     // metode der opdaterer et medlems statistik
    public static void updateMedlem(int idspiller,String fornavn, String efternavn,int cpr,String email,int tlf, String ben,String toejstoerrelse,String land,int idhold){
     try  {
      // kalder DBConnection klassens metode for at forbinde med DB
       Connection conn = DBConnection.getConnection();
         
      // opretter og udf�rer sql statement objekt.
       PreparedStatement prepareStatement = 
         conn.prepareStatement("UPDATE spiller SET fornavn=?, efternavn=?, cpr=?,email=?,tlf=?,ben=?,toejstoerrelse=?,land=? WHERE idspiller=?;");              

       // Tilf�jer til DB med v�rdier fra MedlemOversigtGui's TableModel
        prepareStatement.setString(1, fornavn);
          prepareStatement.setString(2, efternavn);
          prepareStatement.setInt(3, cpr);
          prepareStatement.setString(4, email);
          prepareStatement.setInt(5, tlf);
          prepareStatement.setString(6, ben);
          prepareStatement.setString(7, toejstoerrelse);
          prepareStatement	.setString(8, land);
          prepareStatement.setInt(9, idspiller);
          
          prepareStatement.executeUpdate();
          
             }
       catch (SQLException e)
       {
        System.err.println(e);
       }
 }}  