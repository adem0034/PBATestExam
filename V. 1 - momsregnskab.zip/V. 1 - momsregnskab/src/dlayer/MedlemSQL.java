
/*
 * G�r det muligt at tilf�je spller (OpretMedlemGui)
 * G�r det muligt at opdatere spiller delvist (spillerStatistikGui)
 */
package dlayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class MedlemSQL
{
	// Metode der tilf�jer spiller.
	public static void addSpiller(String fornavn, String efternavn, int cpr,
			String email, int tlf, String ben) throws SQLException 
	{

		try  {
			// Opretter forbindelse til DB og s�tter sql statement ind i PreparedStatement
			Connection conn = DBConnection.getConnection();
			PreparedStatement prepareStatement = null;
			prepareStatement = conn.prepareStatement("INSERT INTO spiller(fornavn, efternavn,cpr,email,tlf,"
					+ "ben,toejstoerrelse,land,idhold) VALUES(?,?,?,?,?,?,?,?,?)");              

			// Tilf�jer til DB med v�rdierne fra OpretMedlemGui
			prepareStatement.setString(1, fornavn);
			prepareStatement.setString(2, efternavn);
			prepareStatement.setInt(3, cpr);
			prepareStatement.setString(4, email);
			prepareStatement.setInt(5, tlf);
			prepareStatement.setString(6, ben);

			prepareStatement.executeUpdate();


		}
		catch (SQLException e)
		{
			System.err.println(e);
		}
	}

	// metode der opdaterer spiller informationerne
	public static void updateSpiller(int spillerId, String fornavn, String efternavn){
		try  {
			Connection conn = DBConnection.getConnection();
			PreparedStatement prepareStatement = 
					conn.prepareStatement("UPDATE spiller SET fornavn=?, efternavn=? WHERE idspiller=?;");              

			prepareStatement.setString(1, fornavn);
			prepareStatement.setString(2, efternavn);
			prepareStatement.setInt(3, spillerId);
			prepareStatement.executeUpdate();

		}
		catch (SQLException e)
		{
			System.err.println(e);
		}
	}
 
}