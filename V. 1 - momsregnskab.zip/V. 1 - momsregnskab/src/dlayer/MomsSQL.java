/*
 * Forbindelse mellem SpillerStatistikGui, Statistik og DB.
 * g�r det muligt at vise spiller statistik 
 * G�r det muligt at opdatere statistik (m�l, kort, idspiller)
 * 
 */
package dlayer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.MomsOpg;

public class MomsSQL {
	
	// Metoden statistik() returnerer en ArrayList af Statistik
	public static ArrayList<MomsOpg> moms() throws SQLException {
//		Opretter en ArrayList statistik, der indeholder Staistik objektet.
		ArrayList<MomsOpg> moms = new ArrayList<MomsOpg>();
		
		// sql statement der skal udf�res
		String sql = "SELECT * FROM regning";
		
		// kalder DBConnections metode - forbinder med DB.
		Connection conn = DBConnection.getConnection();
		
		// opretter og udf�rer sql statement objekt.
		Statement statement = conn.createStatement();
	    statement.execute(sql);
	    
	    // ResultSet objektet indeholder output af data fra sql statement
		ResultSet results = statement.getResultSet();
				
		// k�rer loop for sql statement mens der er r�kker i ResultSet 
		while(results.next()) {
			int bilagNr = results.getInt("bilagNr");
			String supplier = results.getString("supplier");
			String category = results.getString("category");
			String date = results.getString("date");
			boolean paid = results.getBoolean("paid");
			String descript = results.getString("descript");
			String valuta = results.getString("valuta");
			int priceNoVat = results.getInt("priceNoVat");
			int priceVat = results.getInt("priceVat");
		
			// Opretter et nyt objekt af Statistik og tilf�jer data fra st til ArrayListen.
			MomsOpg momsOpg = new MomsOpg(bilagNr, supplier, category, date, paid, descript, valuta, priceNoVat, priceVat);
			moms.add(momsOpg);
			
		}
		// returner ArrayListen statistik og lukker ResultSet og Statement (frig�rer resourcer)
		results.close();
		statement.close();
		return moms;
	}
	
	
	
	
	// for kundefaktura
	public static ArrayList<MomsOpg> faktura() throws SQLException {
//		Opretter en ArrayList statistik, der indeholder Staistik objektet.
		ArrayList<MomsOpg> faktura = new ArrayList<MomsOpg>();
		
		// sql statement der skal udf�res
		String sql = "SELECT * FROM faktura";
		
		// kalder DBConnections metode - forbinder med DB.
		Connection conn = DBConnection.getConnection();
		
		// opretter og udf�rer sql statement objekt.
		Statement statement = conn.createStatement();
	    statement.execute(sql);
	    
	    // ResultSet objektet indeholder output af data fra sql statement
		ResultSet results = statement.getResultSet();
				
		// k�rer loop for sql statement mens der er r�kker i ResultSet 
		while(results.next()) {
			int idFaktura = results.getInt("idFaktura");
			String fornavn = results.getString("fornavn");
			String efternavn = results.getString("efternavn");
			String tlf = results.getString("tlf");
			String email = results.getString("email");
			String vej = results.getString("vej");
			String postnummer = results.getString("postnummer");
			String by = results.getString("by");
			String cvr = results.getString("cvr");
			String virksomhedsnavn = results.getString("virksomhedsnavn");
			String produkt = results.getString("produkt");
			String beskrivelse = results.getString("beskrivelse");
			int antal = Integer.parseInt(results.getString("antal"));
			String valuta = results.getString("valuta");
			int enhedspris = Integer.parseInt(results.getString("enhedspris"));
			int ialtEksklMoms = Integer.parseInt(results.getString("ialtEksklMoms"));
			int ialtInklMoms = Integer.parseInt(results.getString("ialtInklMoms"));
			String dato = results.getString("dato");
			String betalingsfrist = results.getString("betalingsfrist");
			boolean paid = results.getBoolean("paid");
			
			
					
			// Opretter et nyt objekt af Statistik og tilf�jer data fra st til ArrayListen.
			MomsOpg momsOpg = new MomsOpg(idFaktura, fornavn, efternavn, tlf, email, vej,
					postnummer, by, cvr, virksomhedsnavn, produkt, beskrivelse, antal, 
					valuta, enhedspris, ialtEksklMoms, ialtInklMoms, dato, betalingsfrist, paid); 
			
					faktura.add(momsOpg);
			
		}
		// returner ArrayListen statistik og lukker ResultSet og Statement (frig�rer resourcer)
		results.close();
		statement.close();
		return faktura;
	}
	
	
	
	
	
	// total k�bsmoms (indg�ende)
	public static ArrayList<MomsOpg> koebsMoms() throws SQLException {
//		Opretter en ArrayList statistik, der indeholder Staistik objektet.
		ArrayList<MomsOpg> moms = new ArrayList<MomsOpg>();
		
		// sql statement der skal udf�res
		String sql = "SELECT sum(priceVat - priceNoVat) as koebsmoms from regning";
		
		// kalder DBConnections metode - forbinder med DB.
		Connection conn = DBConnection.getConnection();
		
		// opretter og udf�rer sql statement objekt.
		Statement statement = conn.createStatement();
	    statement.execute(sql);
	    
	    // ResultSet objektet indeholder output af data fra sql statement
		ResultSet results = statement.getResultSet();
				
		// k�rer loop for sql statement mens der er r�kker i ResultSet 
		while(results.next()) {
			int koebsmoms = results.getInt("koebsmoms");
			
			MomsOpg koebsmoms1 = new MomsOpg(koebsmoms);
			moms.add(koebsmoms1);
			
			
	
			// Opretter et nyt objekt af Statistik og tilf�jer data fra st til ArrayListen.
			
		}
		// returner ArrayListen statistik og lukker ResultSet og Statement (frig�rer resourcer)
		results.close();
		statement.close();
		return moms;
	}
	
	
//	salgsmoms  alt (udg�ende)
		public static ArrayList<MomsOpg> salgsMoms() throws SQLException {
//			Opretter en ArrayList statistik, der indeholder Staistik objektet.
			ArrayList<MomsOpg> moms = new ArrayList<MomsOpg>();
			
			// sql statement der skal udf�res
			String sql = "SELECT sum(antal * enhedspris) as salgsMoms from faktura";
			
			// kalder DBConnections metode - forbinder med DB.
			Connection conn = DBConnection.getConnection();
			
			// opretter og udf�rer sql statement objekt.
			Statement statement = conn.createStatement();
		    statement.execute(sql);
		    
		    // ResultSet objektet indeholder output af data fra sql statement
			ResultSet results = statement.getResultSet();
					
			// k�rer loop for sql statement mens der er r�kker i ResultSet 
			while(results.next()) {
				int salgsMoms = results.getInt("salgsMoms");
				
				MomsOpg salgsMoms1 = new MomsOpg(salgsMoms, salgsMoms);
				moms.add(salgsMoms1);
				
				
		
				// Opretter et nyt objekt af Statistik og tilf�jer data fra st til ArrayListen.
				
			}
			// returner ArrayListen statistik og lukker ResultSet og Statement (frig�rer resourcer)
			results.close();
			statement.close();
			return moms;
		}
	
	
	
	
	
	
			// metode der opdaterer et medlems statistik
//	public static void updateStatistik(int idSpiller, int mål, int r�dt_kort, int gult_kort){
//		try  {
//			// kalder DBConnections metode - forbinder med DB.
//	 		Connection conn = DBConnection.getConnection();
//	 	   
//	 	// opretter og udf�rer sql statement objekt.
//	 	 PreparedStatement prepareStatement = 
//	 			 conn.prepareStatement("UPDATE spillerstatistik SET mål=?, rødt_kort=?, gult_kort=? "
//	 			 		+ "WHERE idspillerstatistik=?;");              
//
//	 	 // Tilf�jer til DB, efter den f�r v�rdierne fra StatistikGui's TabelModel
//	      prepareStatement.setInt(1, mål);
//	      prepareStatement.setInt(2, r�dt_kort);
//	      prepareStatement.setInt(3, gult_kort);
//	      prepareStatement.setInt(4, idSpiller);
//	      prepareStatement.executeUpdate();
//	      
//	         }
//	   catch (SQLException e)
//	   {
//	    System.err.println(e);
//	   }
//	}
}
