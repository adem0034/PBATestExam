/*
 *  Forbindelse mellem DB og OpretKampOversigt
 *  G�r det muligt at oprette en kamp oversigt
 *  
 */
package dlayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dlayer.DBConnection;

public class OpretKampOversigtSQL {
		// Tilf�jer f�rste tabel af kamp oversigt
	public static void addKampOversigt1(int vundet, int uafgjort, int tabt) throws SQLException 
			   {
			    
			       try  {
			    	   	// Opretter forbindelse til DB og s�tter sql statement ind i PreparedStatement
			    		Connection conn = DBConnection.getConnection();
			    		PreparedStatement prepareStatement = null;
			    		prepareStatement = conn.prepareStatement("INSERT INTO kampoversigt(vundet, tabt, uafgjort) "
			    	 		+ "VALUES(?,?,?)");              

			     	   // Tilf�jer til DB, efter den f�r v�rdierne fra OpretKampOversigtGui's text fields
			    		prepareStatement.setInt(1, vundet);
			    		prepareStatement.setInt(2, tabt);
			         	prepareStatement.setInt(3, uafgjort);
			         	prepareStatement.executeUpdate();
			        
			            }
			      catch (SQLException e)
			      {
			       System.err.println(e);
			      }
			   }
	
	
	
	// Tilf�jer den anden tabel af kamp oversigt
		public static void addKampOversigt2(int tr�ning, int kamp, String dato, String modstander) 
																					throws SQLException {
	
	try  {
		// Opretter forbindelse til DB og s�tter sql statement ind i PreparedStatement
		Connection conn = DBConnection.getConnection();
		PreparedStatement prepareStatement = null;
	   	prepareStatement = conn.prepareStatement("INSERT INTO aktivitet(træning, kamp, dato, modstander) "
	   												+ "VALUES(?,?,?,?)");
	   	// Tilf�jer til DB, efter den f�r v�rdierne fra OpretKampOversigtGui's text fields
	     prepareStatement.setInt(1, tr�ning);
	     prepareStatement.setInt(2, kamp);
	     prepareStatement.setString(3, dato);
	     prepareStatement.setString(4, modstander);
	     prepareStatement.executeUpdate();
	 
	 
	    }
	catch (SQLException e) {
		System.err.println(e);
	}
		}
}
