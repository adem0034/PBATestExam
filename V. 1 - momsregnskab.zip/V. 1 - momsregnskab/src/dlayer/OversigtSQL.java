/*
 * Forbindelse mellem DB, Oversigt og OversigtGui
 * G�r det muligt at vise oversigt over kampe
 * 
 */
package dlayer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Oversigt;

public class OversigtSQL 
{		
	// Metoden Info(), returnerer en ArrayList af Oversigt
	public static ArrayList<Oversigt> Info() throws SQLException {

		//Opretter en ArrayListe kaldet oversigt, der indeholder Oversigt objektet.
			ArrayList<Oversigt> oversigt = new ArrayList<Oversigt>();
					
			// sql statement der skal udf�res
			String sql = "SELECT dato,vundet,uafgjort,tabt,modstander "
            		+ "FROM aktivitet "
            		+ "JOIN kampoversigt " 
            		+ "ON aktivitet.idaktivitet = kampoversigt.idkampoversigt";
			
			// kalder DBConnections metode - forbinder med DB.
			Connection conn = DBConnection.getConnection();
			
			// opretter og udf�rer sql statement objekt.
			Statement statement = conn.createStatement();
	     	statement.execute(sql);
			
	     	// ResultSet objektet indeholder output af data fra sql'ens  statement
	     	ResultSet results = statement.getResultSet();
			
	     	// k�rer loop for sql statements data -- mens der stadig er info i results, k�rer den(ResultSet)
			while(results.next()) {
				
				String dato =  results.getString ("dato");
				String vundet = results.getString("vundet");
				String uafgjort = results.getString("uafgjort");
				String tabt = results.getString("tabt");
				String modstander = results.getString("modstander");
				
				// Opretter et nyt objekt af Oversigt klassen og tilf�jer data.
				Oversigt o = new Oversigt(dato,vundet, uafgjort, tabt,modstander);
				oversigt.add(o);							
			}
			// returner ArrayListen 'oversigt' og lukker ResultSet og Statement (frig�rer resourcer)
			results.close();
			statement.close();
			return oversigt;
		}
}