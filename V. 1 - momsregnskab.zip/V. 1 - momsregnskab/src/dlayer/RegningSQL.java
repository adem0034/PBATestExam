package dlayer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class RegningSQL
{
	// Metode der tilf�jer regning.
	public static void addRegning(String supplier, String category, String date, boolean paid, String descript,
					String valuta, int priceNoVat, int priceVat) throws SQLException 
	{

		try  {
			// Opretter forbindelse til DB og s�tter sql statement ind i PreparedStatement
			Connection conn = DBConnection.getConnection();
			PreparedStatement prepareStatement = null;
			prepareStatement = conn.prepareStatement("INSERT INTO `finances`.`regning` (`supplier`, `category`, "
					+ "`date`, `paid`, `descript`, `valuta`, `priceNoVat`, `priceVat`)"
					+ " VALUES(?,?,?,?,?,?,?,?)");              

			
			
//leverand�r, regningsdato, betalt, betlingsfrist, bilagsnr(auto increment), valuta,
			// beskrvelse, udgfskategori, momssats, eks. moms , ink moms(auto), 
			
			
			// Tilf�jer til DB med v�rdierne fra OpretMedlemGui
			prepareStatement.setString(1, supplier );
			prepareStatement.setString(2, category );
			prepareStatement.setString(3, date);
			prepareStatement.setBoolean(4, paid);
			prepareStatement.setString(5, descript);
			prepareStatement.setString(6, valuta);
			prepareStatement.setInt(7, priceNoVat);
			prepareStatement.setInt(8,  priceVat);

			prepareStatement.executeUpdate();


		}
		catch (SQLException e)
		{
			System.err.println(e);
		}
	}



	// metode der opdaterer spiller informationerne
//	public static void updateSpiller(int spillerId, String fornavn, String efternavn){
//		try  {
//			Connection conn = DBConnection.getConnection();
//			PreparedStatement prepareStatement = 
//					conn.prepareStatement("UPDATE spiller SET fornavn=?, efternavn=? WHERE idspiller=?;");              
//
//			prepareStatement.setString(1, fornavn);
//			prepareStatement.setString(2, efternavn);
//			prepareStatement.setInt(3, spillerId);
//			prepareStatement.executeUpdate();
//
//		}
//		catch (SQLException e)
//		{
//			System.err.println(e);
//		}
//	}
 
}