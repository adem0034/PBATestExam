/*
  * Forbindelse mellem SoegFunktionGui, SoegFunktion og database
 * Muligg�r s�gning efter spiller. 
 * 
 */
package dlayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

import model.SoegFunktion;

public class SoegFunktionSQL 
{ 
	// Metoden soegInfo(), returnerer en ArrayList af SoegFunktion
	public static ArrayList<SoegFunktion> soegInfo() throws SQLException {
		
		//Opretter en ArrayList soeg, der indeholder SoegFunktion objektet.
			ArrayList<SoegFunktion> soeg = new ArrayList<SoegFunktion>();
			
			// pop-up; gemmer input i variabel vari
			String vari = JOptionPane.showInputDialog("Indtast starten af navnet", "Navn");
			
			// sql statement der skal udf�res
			String sql = "SELECT idspiller, fornavn,efternavn, mål, rødt_kort, gult_kort "
            		+ "FROM spiller "
            		+ "LEFT JOIN spillerstatistik "
            		+ "ON spiller.idspiller = spillerstatistik.idspillerstatistik "
            		+ "WHERE fornavn LIKE '" + vari +    "%'";
			
			// kalder DBConnections metode - forbinder med DB.
			Connection conn = DBConnection.getConnection();
			
			// opretter og udf�rer sql statement objekt.
			Statement statement = conn.createStatement();
	     	statement.execute(sql);
	     	
	     	// ResultSet objektet indeholder output af data fra sql statement
			ResultSet results = statement.getResultSet();

			// while loop for sql statements data mens der r�kker i ResultSet objektet
			while(results.next()) {
				int idspiller = results.getInt("idspiller");
				String fornavn = results.getString("fornavn");
				String efternavn = results.getString("efternavn");
				int mål = results.getInt("mål");
				int r�dtKort = results.getInt("rødt_kort");
				int gultKort = results.getInt("gult_kort");
				
				// Opretter et nyt objekt af SoegFunktion og tilf�jer data fra sf til ArrayListen.
				SoegFunktion sf = new SoegFunktion(idspiller, fornavn, efternavn, mål, r�dtKort, gultKort);
				soeg.add(sf);
							
			}
			// returner ArrayListen soeg og lukker ResultSet og Statement (frig�rer resourcer)
			results.close();
			statement.close();
			return soeg;
		}
}