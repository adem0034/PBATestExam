/*
 * Forbindelse mellem SpillerStatistikGui, Statistik og DB.
 * g�r det muligt at vise spiller statistik 
 * G�r det muligt at opdatere statistik (m�l, kort, idspiller)
 * 
 */
package dlayer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Statistik;

public class StatistikSQL {
	
	// Metoden statistik() returnerer en ArrayList af Statistik
	public static ArrayList<Statistik> statistik() throws SQLException {
//		Opretter en ArrayList statistik, der indeholder Staistik objektet.
		ArrayList<Statistik> statistik = new ArrayList<Statistik>();
		
		// sql statement der skal udf�res
		String sql = "SELECT idspiller, fornavn,efternavn, m�l, rødt_kort, gult_kort "
           		+ "FROM spiller "
           		+ "LEFT JOIN spillerstatistik "
           		+ "ON spiller.idspiller = spillerstatistik.idspillerstatistik";
		
		// kalder DBConnections metode - forbinder med DB.
		Connection conn = DBConnection.getConnection();
		
		// opretter og udf�rer sql statement objekt.
		Statement statement = conn.createStatement();
	    statement.execute(sql);
	    
	    // ResultSet objektet indeholder output af data fra sql statement
		ResultSet results = statement.getResultSet();
				
		// k�rer loop for sql statement mens der er r�kker i ResultSet 
		while(results.next()) {
			int idspiller = results.getInt("idspiller");
			String fornavn = results.getString("fornavn");
			String efternavn = results.getString("efternavn");
			int m�l = results.getInt("m�l");
			int r�dt_kort = results.getInt("rødt_kort");
			int gult_kort = results.getInt("gult_kort");
		
			// Opretter et nyt objekt af Statistik og tilf�jer data fra st til ArrayListen.
			Statistik st = new Statistik(idspiller,fornavn,efternavn,m�l,r�dt_kort,gult_kort);
			statistik.add(st);  
		}
		// returner ArrayListen statistik og lukker ResultSet og Statement (frig�rer resourcer)
		results.close();
		statement.close();
		return statistik;
	}
	
	
			// metode der opdaterer et medlems statistik
	public static void updateStatistik(int idSpiller, int mål, int r�dt_kort, int gult_kort){
		try  {
			// kalder DBConnections metode - forbinder med DB.
	 		Connection conn = DBConnection.getConnection();
	 	   
	 	// opretter og udf�rer sql statement objekt.
	 	 PreparedStatement prepareStatement = 
	 			 conn.prepareStatement("UPDATE spillerstatistik SET mål=?, rødt_kort=?, gult_kort=? "
	 			 		+ "WHERE idspillerstatistik=?;");              

	 	 // Tilf�jer til DB, efter den f�r v�rdierne fra StatistikGui's TabelModel
	      prepareStatement.setInt(1, mål);
	      prepareStatement.setInt(2, r�dt_kort);
	      prepareStatement.setInt(3, gult_kort);
	      prepareStatement.setInt(4, idSpiller);
	      prepareStatement.executeUpdate();
	      
	         }
	   catch (SQLException e)
	   {
	    System.err.println(e);
	   }
	}
}
