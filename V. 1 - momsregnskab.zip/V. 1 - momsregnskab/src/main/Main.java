/*

 * K�rer hele programmet.
 */
package main;

import presentation.GuiMain;

public class Main 
{
	public static void main(String[] args) 
	{
		new GuiMain();
	}
}
 