package model;

public class Medlem {
	private int idspiller;
	private String fornavn;
	private String efternavn;
	protected int cpr;
	private String email; 
	private int tlf;
	private String ben;
	private String toejstoerrelse;
	private String land;
	private int idhold;
	
	public Medlem(int idspiller,String fornavn, String efternavn,int cpr, 
					String email,int tlf, String ben, String toejstoerrelse, String land, int idhold) {

//		super();
		this.idspiller = idspiller;
		this.fornavn = fornavn;
		this.efternavn = efternavn;
		this.cpr = cpr;
		this.email = email;
		this.tlf = tlf;
		this.ben = ben; 
		this.toejstoerrelse = toejstoerrelse;
		this.land = land;
		this.idhold = idhold;
		}
//	public int getIdspiller() {
//		return idspiller;
//   }
//	public void setIdspiller(int idspiller) {
//		this.idspiller = idspiller;
//   }
//
	public String getFornavn() {
		return fornavn;
  }
//	public void setFornavn(String fornavn) {
//		this.fornavn = fornavn;
//  }
//	public String getEfternavn() {
//		return efternavn;
//  }
//	public void setEfternavn(String efternavn) {
//		this.efternavn = efternavn;
//  }
//	public int getCpr() {
//		return cpr;
//  }
//	public void setCpr(int cpr) {
//		this.cpr = cpr;
//  }
//	public String getEmail() {
//		return email;
//  }
//	public void setEmail(String email) {
//		this.email = email;
//  }
//	public int getTlf() {
//		return tlf;
//  }
//	public void setTlf(int tlf) {
//		this.tlf = tlf;
//  }
//	public String getBen() {
//		return ben;
//  }
//	public void setBen(String ben) {
//		this.ben = ben;
//  }
//	public String getToejstoerrelse() {
//		return toejstoerrelse;
//  }
//	public void setToejstoerrelse(String toejstoerrelse) {
//		this.toejstoerrelse = toejstoerrelse;
//  }
//	public String getLand() {
//		return land;
//  }
//	public void setLand(String land) {
//		this.land = land;
//  }
//	public int getIdhold() {
//		return idhold;
//  }
//	public void setIdHold(int idhold) {
//		this.idhold = idhold;
//  }

//
//	public String toString() {
//		return "Medlem [idspiller=" + idspiller + ",fornavn=" + fornavn
//				+ ", efternavn=" + efternavn + ", cpr=" + cpr + ", email="
//				+ email + ", tlf=" + tlf + ", ben=" + ben
//				+ ", toejstoerrelse=" + toejstoerrelse + ", land=" + land
//				+ ", idhold=" + idhold + "]";
//  }
	public Object[] toObjectArray	() {
		Object[] array = new Object[10];
		array[0] = this.idspiller;
		array[1] = this.fornavn;
		array[2] = this.efternavn;
		array[3] = this.cpr;
		array[4] = this.email;
		array[5] = this.tlf;
		array[6] = this.ben;
		array[7] = this.toejstoerrelse;
		array[8] = this.land;
		array[9] = this.idhold;
		
		return array;
	}
}