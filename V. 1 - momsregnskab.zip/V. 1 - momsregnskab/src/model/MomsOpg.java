package model;


public class MomsOpg
{
	private int bilagNr;
	private String supplier;
	private String category;
	private String date;
	private boolean paid;
	private String descript;
	private String valuta;
	private int priceNoVat;
	private int priceVat;
	private int koebsmoms;
	private double salgsMoms;

	private int idFaktura;
	private String fornavn;
	private String efternavn;
	private String tlf;
	private String email;
	private String vej;
	private String postnummer;
	private String by;
	private String cvr;
	private String virksomhedsnavn;
	private String produkt;
	private String beskrivelse;
	private int antal;
	private String valuta2;
	private int enhedspris;
	private int ialtEksklMoms;
	private int ialtInklMoms;
	private String dato;
	private String betalingsfrist;
	private boolean paid2;


	// for faktura
	public MomsOpg(int idFaktura, String fornavn,
			String efternavn, String tlf, String email, String vej, String postnummer, String by, String cvr,
			String virksomhedsnavn, String produkt, String beskrivelse, int antal, String valuta2, int enhedspris,
			int ialtEksklMoms, int ialtInklMoms, String dato, String betalingsfrist, boolean paid2 ) {
		super();

		this.idFaktura = idFaktura;
		this.fornavn = fornavn;
		this.efternavn = efternavn;
		this.tlf = tlf;
		this.email = email;
		this.vej = vej;
		this.postnummer = postnummer;
		this.by = by;
		this.cvr = cvr;
		this.virksomhedsnavn = virksomhedsnavn;
		this.produkt = produkt;
		this.beskrivelse = beskrivelse;
		this.antal = antal;
		this.valuta2 = valuta2;
		this.enhedspris = enhedspris;
		this.ialtEksklMoms = ialtEksklMoms;
		this.ialtInklMoms = ialtInklMoms;
		this.dato = dato;
		this.betalingsfrist = betalingsfrist;
		this.paid2 = paid2;
	}




 




	public MomsOpg(int bilagNr, String supplier, String category, String date, boolean paid, String descript,
			String valuta, int priceNoVat, int priceVat) {
		super();
		this.bilagNr = bilagNr;
		this.supplier = supplier;
		this.category = category;
		this.date = date;
		this.paid = paid;
		this.descript = descript;
		this.valuta = valuta;
		this.priceNoVat = priceNoVat;
		this.priceVat = priceVat;

	}

	public MomsOpg() {

	}






	public MomsOpg(int koebsmoms) {
		// TODO Auto-generated constructor stub
		this.koebsmoms = koebsmoms;
	}



	public  MomsOpg(int salgsMoms, int sumting) {
		// TODO Auto-generated constructor stub
		this.salgsMoms = salgsMoms;
	}





	public Object[] toObjectArray2() {
		Object[] array = new Object[1];
		array[0] = this.koebsmoms;
		return array;

	}





	public Object[] toObjectArray() {
		Object[] array = new Object[9];
		array[0] = this.bilagNr;
		array[1] = this.supplier;
		array[2] = this.category;
		array[3] = this.date;
		array[4] = this.paid;
		array[5] = this.descript;
		array[6] = this.valuta;
		array[7] = this.priceNoVat;
		array[8] = this.priceVat;
		return array;
	}





	public Object[] toObjectArray3() {
		// TODO Auto-generated method stub
		Object[] array = new Object[1];
		array[0] = this.salgsMoms;
		return array;
	}



	public Object[] toObjectArray4() {
		Object[] array = new Object[20];
		array[0] = this.idFaktura;
		array[1] = this.fornavn;
		array[2] = this.efternavn;
		array[3] = this.tlf;
		array[4] = this.email;
		array[5] = this.vej;
		array[6] = this.postnummer;
		array[7] = this.by;
		array[8] = this.cvr;
		array[9] = this.virksomhedsnavn;
		array[10] = this.produkt;
		array[11] = this.beskrivelse;
		array[12] = this.antal;
		array[13] = this.valuta2;
		array[14] = this.enhedspris;
		array[15] = this.ialtEksklMoms;
		array[16] = this.ialtInklMoms;
		array[17] = this.dato;
		array[18] = this.betalingsfrist;
		array[19] = this.paid2;




		return array;
	}
}