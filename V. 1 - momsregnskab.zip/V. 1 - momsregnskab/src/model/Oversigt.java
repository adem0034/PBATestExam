package model;

public class Oversigt 
{
	private String dato;
	private String vundet;
	private String uafgjort;
	private String tabt;
	private String modstander;
	
	public Oversigt(String dato, String vundet, String uafgjort, String tabt, String modstander)
	{
//		super();
		this.dato = dato;		
		this.vundet = vundet;
		this.uafgjort = uafgjort;
		this.tabt = tabt;
		this.modstander = modstander;
	}

//	public String getDato() {
//		return dato;
//	}
//
//	public void setDato(String dato) {
//		this.dato = dato;
//	}
//
//	public String getUafgjort() {
//		return uafgjort;
//	}
//
//	public void setUafgjort(String uafgjort) {
//		this.uafgjort = uafgjort;
//	}
//
//	public String getTabt() {
//		return tabt;
//	}
//
//	public void setTabt(String tabt) {
//		this.tabt = tabt;
//	}
//
//	public String getModstander() {
//		return modstander;
//	}
//
//	public void setModstander(String modstander) {
//		this.modstander = modstander;
//	}
	
	
//	@Override
//	public String toString() {
//		return "Oversigt [dato=" + dato + ", vundet=" + vundet + ", uafgjort="
//				+ uafgjort + ", tabt=" + tabt + ", modstander=" + modstander
//				+ "]";
//	}

	public Object[] toObjectArray() {
		Object[] array = new Object[5];
		array[0] = this.dato;
		array[1] = this.vundet;
		array[2] = this.uafgjort;
		array[3] = this.tabt;
		array[4] = this.modstander;
		return array;
	}
}