package model;


public class Statistik
{
	private int idspiller;
	private String fornavn;
	private String efternavn;
	private int m�l;
	private int r�dt_kort;
	private int gult_kort;
	
	public Statistik(int idspiller, String fornavn, String efternavn,
			int m�l, int r�dt_kort, int gult_kort)
	{ 
//		super();
		this.idspiller = idspiller;
		this.fornavn = fornavn;
		this.efternavn = efternavn;
		this.m�l = m�l;
		this.r�dt_kort = r�dt_kort;
		this.gult_kort = gult_kort;
	}

//	public int getIdspiller() {
//		return idspiller;
//	}
//
//	public void setIdspiller(int idspiller) {
//		this.idspiller = idspiller;
//	}
//
//	public String getFornavn() {
//		return fornavn;
//	}
//
//	public void setFornavn(String fornavn) {
//		this.fornavn = fornavn;
//	}
//
//	public String getEfternavn() {
//		return efternavn;
//	}
//
//	public void setEfternavn(String efternavn) {
//		this.efternavn = efternavn;
//	}
//
//	public int getMål() {
//		return mål;
//	}
//
//	public void setMål(int mål) {
//		this.mål = mål;
//	}
//
//	public int getRødt_kort() {
//		return rødt_kort;
//	}
//
//	public void setRødt_kort(int rødt_kort) {
//		this.rødt_kort = rødt_kort;
//	}
//
//	public int getGult_kort() {
//		return gult_kort;
//	}
//
//	public void setGult_kort(int gult_kort) {
//		this.gult_kort = gult_kort;
//	}

//	@Override
//	public String toString() {
//		return "StatistikModel [idspiller=" + idspiller + ", fornavn="
//				+ fornavn + ", efternavn=" + efternavn + ", mål=" + mål
//				+ ", rødt_kort=" + rødt_kort + ", gult_kort=" + gult_kort + "]";
//		
//		
//	}
	public Object[] toObjectArray() {
		Object[] array = new Object[6];
		array[0] = this.idspiller;
		array[1] = this.fornavn;
		array[2] = this.efternavn;
		array[3] = this.m�l;
		array[4] = this.r�dt_kort;
		array[5] = this.gult_kort;
		return array;
	}
}