/*
 * Medlem der indeholder de 3 undermetoders knapper (opret,oversigt,slet)
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

import dlayer.SletFunktionSQL;

public class Aarsopgoerelse {
 
  public Aarsopgoerelse()
  {
   init();
  }
  
  public static void init() 
  {
	  // Opretter en JFrame og  laver designet
	final JFrame mainframe = new JFrame("GJKFK");
    mainframe.setSize(630,490);
    mainframe.setVisible(true);
    mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    mainframe.getContentPane().setLayout(null);
    mainframe.setLocationRelativeTo(null);
    
//    // Opretter btnMedlem og kalder OpretMedlemGuis metode.
//    JButton btnOpretMedlem = new JButton("Opret Medlem");
//    btnOpretMedlem.setBounds(90, 13, 118, 29);
//    mainframe.getContentPane().add(btnOpretMedlem);
//    btnOpretMedlem.addActionListener(new ActionListener() {
//     public void actionPerformed(ActionEvent e) {
//      
//      OpretMedlemGui.init();
//      }
//     });

    // Opretter btnTilbage og lukker vinduet ned.
    JButton btnTilbage = new JButton("Tilbage");
    btnTilbage.setBounds(12, 405, 97, 29);
    mainframe.getContentPane().add(btnTilbage);
    btnTilbage.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
     mainframe.setVisible(false);
    }
   });
   }
 }