/*
 * Medlem der indeholder de 3 undermetoders knapper (opret,oversigt,slet)
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import dlayer.FakturaSQL;

public class KundeFaktGUI {
	private static JTextField txtValuta;
	private static JTextField txtProdukt;
	private static JTextField txtFornavn;
	private static JTextField txtEfternavn;
	private static JTextField txtEmail;
	private static JTextField txtTlf;
	private static JTextField txtVej;
	private static JTextField txtPostnummer;
	private static JTextField txtBy;
	private static JTextField txtAntal;
	private static JTextField txtCvr;
	private static JTextField txtVirknavn;
	private static JTextField txtEnhedspris;
	private static JTextField txtEksmomssum;
	private static JTextField txtInkmomssum;
	private static JTextField txtDato;
	private static JTextField txtBetalingsfrist;

	public KundeFaktGUI()
	{
		init();
	}

	public static void init() 
	{
		// Opretter en JFrame og  laver designet
		final JFrame mainframe = new JFrame("GJKFK");
		mainframe.setSize(869,908);
		mainframe.setVisible(true);
		mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainframe.setLocationRelativeTo(null);
		mainframe.getContentPane().setLayout(null);

		// Opretter btnTilbage og lukker vinduet ned.
		JButton btnTilbage = new JButton("Tilbage");
		btnTilbage.setBounds(23, 819, 97, 29);
		mainframe.getContentPane().add(btnTilbage);

		JLabel lblBetaltikkeBetalt = new JLabel("betalt/ikke betalt");
		lblBetaltikkeBetalt.setBounds(12, 769, 95, 16);
		mainframe.getContentPane().add(lblBetaltikkeBetalt);

		JCheckBox chckbxBetalt = new JCheckBox("Betalt");
		chckbxBetalt.setBounds(253, 775, 113, 25);
		mainframe.getContentPane().add(chckbxBetalt);

		JLabel lblValuta = new JLabel("Valuta");
		lblValuta.setBounds(12, 497, 56, 16);
		mainframe.getContentPane().add(lblValuta);

		txtValuta = new JTextField();
		txtValuta.setBounds(250, 494, 116, 22);
		txtValuta.setText("valuta");
		mainframe.getContentPane().add(txtValuta);
		txtValuta.setColumns(10);

		JLabel lblBeskrivelse = new JLabel("Beskrivelse");
		lblBeskrivelse.setBounds(12, 369, 128, 16);
		mainframe.getContentPane().add(lblBeskrivelse);

		JTextPane txtBeskrivelse = new JTextPane();
		txtBeskrivelse.setBounds(240, 369, 164, 60);
		txtBeskrivelse.setText("beskrivelse");
		mainframe.getContentPane().add(txtBeskrivelse);

		JLabel lblUploadBilag = new JLabel("Upload bilag:");
		lblUploadBilag.setBounds(531, 369, 113, 16);
		mainframe.getContentPane().add(lblUploadBilag);

		JButton btnGemRegning = new JButton("Gem kundefaktura");
		btnGemRegning.setBounds(414, 821, 177, 25);
		btnGemRegning.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//    		 SQL stuff here .... 
				
				String fornavn = txtFornavn.getText();
				String efternavn = txtEfternavn.getText();
				String tlf = txtTlf.getText();
				String email = txtEmail.getText();
				String vej = txtVej.getText();
				String postnummer = txtPostnummer.getText();
				String by = txtBy.getText();
				String cvr = txtCvr.getText();
				String virksomhedsnavn = txtVirknavn.getText();
				String produkt = txtProdukt.getText();
				String beskrivelse = txtBeskrivelse.getText();
				int antal = Integer.parseInt(txtAntal.getText());
				String valuta = txtValuta.getText();
				int enhedspris = Integer.parseInt(txtEnhedspris.getText());
				int eksMomsSum = Integer.parseInt(txtEksmomssum.getText());
				int inkMomsSum = Integer.parseInt(txtInkmomssum.getText());
				String dato = txtDato.getText();
				String betalingsfrist = txtBetalingsfrist.getText();
				boolean betalt = chckbxBetalt.isSelected();
				
				System.out.println(betalt);
				
				 try {
					 // her sender/videregiver den variablerne til .addSpiller
					 FakturaSQL.addFaktura(fornavn, efternavn, tlf, email, vej, postnummer, by, cvr, virksomhedsnavn, produkt, beskrivelse, antal, valuta, enhedspris, eksMomsSum, inkMomsSum, dato, betalingsfrist, betalt);
					 } catch (SQLException e) {
						 // TODO Auto-generated catch block
						 e.printStackTrace();
						 }
				 // printer bekr�ftelse og disposer mainframe'en.
				 JOptionPane.showMessageDialog(null, "Fakturaen for " + fornavn + " " + virksomhedsnavn + " " +" er oprettet i Databasen");
				 mainframe.dispose(); 
				
			

				
			}
		});
		mainframe.getContentPane().add(btnGemRegning);
		
		JLabel lblFornavn = new JLabel("Fornavn");
		lblFornavn.setBounds(12, 36, 110, 16);
		mainframe.getContentPane().add(lblFornavn);
		
		JLabel lblEfternavn = new JLabel("Efternavn");
		lblEfternavn.setBounds(12, 65, 56, 16);
		mainframe.getContentPane().add(lblEfternavn);
		
		JLabel lblProdukt = new JLabel("Produkt");
		lblProdukt.setBounds(12, 333, 56, 16);
		mainframe.getContentPane().add(lblProdukt);
		
		txtProdukt = new JTextField();
		txtProdukt.setText("produkt");
		txtProdukt.setBounds(240, 333, 116, 22);
		mainframe.getContentPane().add(txtProdukt);
		txtProdukt.setColumns(10);
		
		txtFornavn = new JTextField();
		txtFornavn.setText("Fornavn");
		txtFornavn.setBounds(240, 33, 116, 22);
		mainframe.getContentPane().add(txtFornavn);
		txtFornavn.setColumns(10);
		
		txtEfternavn = new JTextField();
		txtEfternavn.setText("Efternavn");
		txtEfternavn.setBounds(240, 62, 116, 22);
		mainframe.getContentPane().add(txtEfternavn);
		txtEfternavn.setColumns(10);
		
		txtEmail = new JTextField();
		txtEmail.setText("Email");
		txtEmail.setBounds(240, 121, 116, 22);
		mainframe.getContentPane().add(txtEmail);
		txtEmail.setColumns(10);
		
		JLabel lblTlf = new JLabel("Tlf");
		lblTlf.setBounds(12, 91, 56, 16);
		mainframe.getContentPane().add(lblTlf);
		
		txtTlf = new JTextField();
		txtTlf.setText("tlf");
		txtTlf.setBounds(240, 88, 116, 22);
		mainframe.getContentPane().add(txtTlf);
		txtTlf.setColumns(10);
		
		JLabel lblVej = new JLabel("Vej");
		lblVej.setBounds(12, 155, 56, 16);
		mainframe.getContentPane().add(lblVej);
		
		txtVej = new JTextField();
		txtVej.setText("vej");
		txtVej.setBounds(240, 149, 116, 22);
		mainframe.getContentPane().add(txtVej);
		txtVej.setColumns(10);
		
		JLabel lblPostnummer = new JLabel("postnummer");
		lblPostnummer.setBounds(12, 196, 110, 16);
		mainframe.getContentPane().add(lblPostnummer);
		
		txtPostnummer = new JTextField();
		txtPostnummer.setText("postnummer");
		txtPostnummer.setBounds(240, 190, 116, 22);
		mainframe.getContentPane().add(txtPostnummer);
		txtPostnummer.setColumns(10);
		
		txtBy = new JTextField();
		txtBy.setText("by");
		txtBy.setBounds(240, 227, 116, 22);
		mainframe.getContentPane().add(txtBy);
		txtBy.setColumns(10);
		
		txtAntal = new JTextField();
		txtAntal.setText("antal");
		txtAntal.setBounds(250, 442, 116, 22);
		mainframe.getContentPane().add(txtAntal);
		txtAntal.setColumns(10);
		
		JLabel lblBy = new JLabel("by");
		lblBy.setBounds(23, 234, 56, 16);
		mainframe.getContentPane().add(lblBy);
		
		JLabel lblEmail = new JLabel("email");
		lblEmail.setBounds(12, 120, 56, 16);
		mainframe.getContentPane().add(lblEmail);
		
		JLabel lblCvr = new JLabel("cvr");
		lblCvr.setBounds(12, 264, 56, 16);
		mainframe.getContentPane().add(lblCvr);
		
		txtCvr = new JTextField();
		txtCvr.setText("cvr");
		txtCvr.setBounds(240, 261, 116, 22);
		mainframe.getContentPane().add(txtCvr);
		txtCvr.setColumns(10);
		
		JLabel lblVirksomhedsnavn = new JLabel("virksomhedsnavn");
		lblVirksomhedsnavn.setBounds(12, 296, 128, 16);
		mainframe.getContentPane().add(lblVirksomhedsnavn);
		
		txtVirknavn = new JTextField();
		txtVirknavn.setText("virkNavn");
		txtVirknavn.setBounds(240, 293, 116, 22);
		mainframe.getContentPane().add(txtVirknavn);
		txtVirknavn.setColumns(10);
		
		JLabel lblAntal = new JLabel("Antal");
		lblAntal.setBounds(12, 445, 56, 16);
		mainframe.getContentPane().add(lblAntal);
		
		JLabel lblEnhedspris = new JLabel("Enhedspris");
		lblEnhedspris.setBounds(12, 538, 164, 16);
		mainframe.getContentPane().add(lblEnhedspris);
		
		txtEnhedspris = new JTextField();
		txtEnhedspris.setText("Enhedspris");
		txtEnhedspris.setBounds(250, 535, 116, 22);
		mainframe.getContentPane().add(txtEnhedspris);
		txtEnhedspris.setColumns(10);
		
		JLabel lblEksmomssum = new JLabel("eksMomsSum");
		lblEksmomssum.setBounds(23, 596, 97, 16);
		mainframe.getContentPane().add(lblEksmomssum);
		
		txtEksmomssum = new JTextField();
		txtEksmomssum.setText("EksMomsSum");
		txtEksmomssum.setBounds(250, 593, 116, 22);
		mainframe.getContentPane().add(txtEksmomssum);
		txtEksmomssum.setColumns(10);
		
		txtInkmomssum = new JTextField();
		txtInkmomssum.setText("inkMomsSum");
		txtInkmomssum.setBounds(250, 626, 116, 22);
		mainframe.getContentPane().add(txtInkmomssum);
		txtInkmomssum.setColumns(10);
		
		JLabel lblInkmomssum = new JLabel("inkMomsSum");
		lblInkmomssum.setBounds(23, 629, 56, 16);
		mainframe.getContentPane().add(lblInkmomssum);
		
		JLabel lblDato = new JLabel("Dato");
		lblDato.setBounds(23, 672, 56, 16);
		mainframe.getContentPane().add(lblDato);
		
		txtDato = new JTextField();
		txtDato.setText("dato");
		txtDato.setBounds(250, 669, 116, 22);
		mainframe.getContentPane().add(txtDato);
		txtDato.setColumns(10);
		
		JLabel lblBetalingsfrist = new JLabel("Betalingsfrist");
		lblBetalingsfrist.setBounds(12, 720, 164, 16);
		mainframe.getContentPane().add(lblBetalingsfrist);
		
		txtBetalingsfrist = new JTextField();
		txtBetalingsfrist.setText("Betalingsfrist");
		txtBetalingsfrist.setBounds(250, 717, 116, 22);
		mainframe.getContentPane().add(txtBetalingsfrist);
		txtBetalingsfrist.setColumns(10);






		//    System.out.println(chckbxBetalt.isSelected());

		btnTilbage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.setVisible(false);
			}
		});




	}
}