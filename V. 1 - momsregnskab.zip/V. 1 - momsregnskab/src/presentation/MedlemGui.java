/*
 * Medlem der indeholder de 3 undermetoders knapper (opret,oversigt,slet)
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

import dlayer.SletFunktionSQL;

public class MedlemGui {
 
  public MedlemGui()
  {
   init();
  }
  
  public static void init() 
  {
	  // Opretter en JFrame og  laver designet
	final JFrame mainframe = new JFrame("GJKFK");
    mainframe.setSize(630,490);
    mainframe.setVisible(true);
    mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    mainframe.setLayout(null);
    mainframe.setLocationRelativeTo(null);
    
    // Opretter btnMedlem og kalder OpretMedlemGuis metode.
    JButton btnOpretMedlem = new JButton("Opret Medlem");
    btnOpretMedlem.setBounds(90, 13, 118, 29);
    mainframe.add(btnOpretMedlem);
    btnOpretMedlem.addActionListener(new ActionListener() {
     public void actionPerformed(ActionEvent e) {
      
      OpretMedlemGui.init();
      }
     });
    
    // Opretter btnSletMedlem og kalder SletFunktionSQLs metode
    JButton btnSletMedlem = new JButton("Slet Medlem");
    btnSletMedlem.setBounds(370, 13, 118, 29);
    mainframe.add(btnSletMedlem);
    btnSletMedlem.addActionListener(new ActionListener() {
     public void actionPerformed(ActionEvent e) {
      
      SletFunktionSQL.sletMedlem();
      
     }
    });
    
    // Opretter btnMedlemOversigt og kalder MedlemOVersigt metoden
    JButton btnMedlemOversigt = new JButton("Medlem Oversigt");
    btnMedlemOversigt.setBounds(220, 13, 145, 29);
    mainframe.add(btnMedlemOversigt);
    btnMedlemOversigt.addActionListener(new ActionListener() {
     public void actionPerformed(ActionEvent e) {
      
    	MedlemOversigtGui.init();
      
     }
    });

    // Opretter btnTilbage og lukker vinduet ned.
    JButton btnTilbage = new JButton("Tilbage");
    btnTilbage.setBounds(12, 405, 97, 29);
    mainframe.add(btnTilbage);
    btnTilbage.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
     mainframe.setVisible(false);
    }
   });
   }
 }