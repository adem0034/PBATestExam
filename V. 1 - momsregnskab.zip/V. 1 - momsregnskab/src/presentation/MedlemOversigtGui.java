 /*
 * GUI der indeholder tabel som viser medlem oversigt - og som g�r det muligt at �ndre i tabellen
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import model.Medlem;
import dlayer.MedlemOversigtSQL;

public class MedlemOversigtGui {

	// fields
 private static JTable table;
 private static JFrame mainframe;
 	
 	// k�rer metode
 public MedlemOversigtGui() {
  init();
 }


 public static void init() {

	  // Opretter en JFrame og  laver designet
  mainframe = new JFrame("GJKFK");
  mainframe.setSize(630, 490);
  mainframe.setVisible(true);
  mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  mainframe.setLayout(null);
  mainframe.setLocationRelativeTo(null);

  // tilf�jer en "scroll" funktion 
  JScrollPane scrollPane = new JScrollPane();
  scrollPane.setBounds(22, 75, 565, 296);
  mainframe.add(scrollPane);

  // opretter en Jtable og tilf�jer dertil scrollpane
  table = new JTable();
  scrollPane.setViewportView(table);
  table.setVisible(true);

  // ArrayList "results" af typen Medlem 
  ArrayList<Medlem> results = null;
  
  // Returnerer ArrayList af typen Medlem
  try {
   results = MedlemOversigtSQL.medlem();
  } catch (SQLException e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
  }
  
  // Opretter object der navngives "header" og giver den parametre. 
  Object[] header = { "idspiller","fornavn", "efternavn", "cpr", "email", "tlf",
    "ben", "toejstoerrelse", "land", "idhold" };
  
  //Opretter et todimentionelt array (kaldet data) af Object
  Object[][] data = new Object[results.size()][5]; 

  //Looper igennem hvert element i results ArrayListen  
  int i = 0;
  for (Medlem medlem : results) {
	  
  // toObjectArray returnere et object array, hvilket blive gemt i data[].
   data[i] = medlem.toObjectArray();
   i++;
  }
  // Opretter en DefaultTableModel, og inds�tter b�de data og header
  DefaultTableModel model = new DefaultTableModel(data, header);
  model.setColumnIdentifiers(header);
  table.setModel(model);

  	// opretter btnTIlbage 
  final JButton btnTilbage = new JButton("Tilbage");
  btnTilbage.setBounds(12, 401, 117, 29);
  mainframe.getContentPane().add(btnTilbage);

  	// g�r mainframe usynlig / lukker ned ved tryk p� tilbage
  btnTilbage.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    mainframe.setVisible(false);
   }
  });
  
	// Opretter btnGem
  final JButton btnGem = new JButton("Gem");
  btnGem.setBounds(460, 401, 117, 29);
  mainframe.getContentPane().add(btnGem);
  btnGem.addActionListener(new ActionListener() {

	  // Funktionaliteten i gem knappen herunder
	public void actionPerformed(ActionEvent e) {
		
		JOptionPane.showMessageDialog(null, "Informationen er blevet opdateret");
	    
		// indstiller tabellen.
		TableModel model = table.getModel();
	    int rows = model.getRowCount();
	
	    // loop: mens der stadig er flere r�kker, tager den v�rdien af den enkelte r�kke
	    // og sender informationerne til .updateMedlem, som sender til DB == medlem opdateret
	    for (int i = 0; i < rows; i++) {
	    	
	    int idspiller = Integer.parseInt("" + model.getValueAt(i, 0));
	    String fornavn = (String) model.getValueAt(i, 1);
	    String efternavn = (String) model.getValueAt(i, 2);
	    int cpr = Integer.parseInt("" + model.getValueAt(i, 3));
	    String email = (String) model.getValueAt(i, 4);
     	int tlf = Integer.parseInt("" + model.getValueAt(i, 5));
	    String ben = (String) model.getValueAt(i, 6);
	    String toejstoerrelse = (String) model.getValueAt(i, 7);
	    String land = (String) model.getValueAt(i, 8);
	    int idhold = Integer.parseInt("" + model.getValueAt(i, 9));
     
     MedlemOversigtSQL.updateMedlem(idspiller,fornavn, efternavn, cpr,
    		 						email, tlf, ben, toejstoerrelse, land, idhold);
    }
	    // disposer frame efter informationer er gemt
    mainframe.dispose();

   }
  });
 }
}