/*
 * Gui der viser tabel over spillerstatisik - og som g�r det muligt, at �ndre info i tabellen
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dlayer.MomsSQL;
import model.MomsOpg;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;

public class MomsopgGUI {
	public MomsopgGUI() {
		init();
	}

	//field
	private static JTable table; 
	private static JTable table2;
	private static JTable table3;
	private static JTable table4;



	public static void init() {
		// Opretter en JFrame og  laver designet
		final JFrame mainframe = new JFrame("Momsopg�relse");
		mainframe.setSize(1067,1182);
		mainframe.setVisible(true);
		mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainframe.setLocationRelativeTo(null);

		try {
			mainframe.getContentPane().setLayout(null);
			// tilf�jer en "scroll" funktion 
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(34, 532, 785, 115);
			mainframe.getContentPane().add(scrollPane);

			// opretter en jTable og s�tter scrollPane sammen
			table = new JTable();
			scrollPane.setViewportView(table);
			table.setVisible(true);


			
			
			JScrollPane scrollPane2 = new JScrollPane();
			scrollPane2.setBounds(436, 32, 314, 96);
			mainframe.getContentPane().add(scrollPane2);

			
			table2 = new JTable();
			table2.setBounds(135, 229, 650, 64);
			scrollPane2.setViewportView(table2);
			table2.setVisible(true);
//			scrollPane2.setViewportView(table2);

			
			
			JScrollPane scrollPane3 = new JScrollPane();
			scrollPane3.setBounds(55, 42, 314, 96);
			mainframe.getContentPane().add(scrollPane3);
			
			
			table3 = new JTable();
			table3.setBounds(135, 229, 650, 64);
			scrollPane3.setViewportView(table3);
			table3.setVisible(true);
//			scrollPane2.setViewportView(table2)
			
			
			
			JScrollPane scrollPane4 = new JScrollPane();
			scrollPane4.setBounds(34, 781, 785, 96);
			mainframe.getContentPane().add(scrollPane4);
			
			
			table4 = new JTable();
			table4.setBounds(135, 229, 650, 64);
			scrollPane4.setViewportView(table4);
			table4.setVisible(true);
//			scrollPane2.setViewportView(table2)


			/* Kalder StatistikSQL. statistik() og s�tter v�rdien til at v�re en ArrayList
			af typen Statistik.*/
			ArrayList<MomsOpg> results = MomsSQL.moms();


			//			ArrayList<MomsOpg> resultKoebsMoms = MomsSQL.koebsMoms();

			
			// Opretter object der navngives "header" og giver den parametre. 
			Object[] header = {"Bilag","Leverand�r", "Udgiftskategori", "Dato", "Betalt", "beskrivelse", 
					"Valuta", "Eksl. moms", "inkl. moms"};

			//Opretter et todimentionelt array (kaldet data) af Object
			Object[][] data = new Object[results.size()][];

			//Looper igennem hvert element i results ArrayListen  
			int i=0;
			for (MomsOpg momsOpg : results) {

				// toObjectArray returnere et object array, hvilket blive gemt i data[].
				data[i] = momsOpg.toObjectArray();
				i++;
			}
			
			
			
			
			
			// for faktura .. vist alt
			ArrayList<MomsOpg> fakturaRes = MomsSQL.faktura();


			//			ArrayList<MomsOpg> resultKoebsMoms = MomsSQL.koebsMoms();

			
			// Opretter object der navngives "header" og giver den parametre. 
			Object[] header4 = {"idFaktura","Fornavn", "Efternvn", "Tlf", "Email", "Vej", 
					"Postnummer", "By", "CVR", "Virksomhedsnan", "Produkt", "Beskrivelse","Antal", 
					"Valuta", "Enhedspris", "i Alt eks. moms", "I alt inkl. moms", 
					"Dato oprettet", "Betalingsfrist", "betalt"};

			//Opretter et todimentionelt array (kaldet data) af Object
			Object[][] dataFak = new Object[fakturaRes.size()][];

			//Looper igennem hvert element i results ArrayListen  
			int m=0;
			for (MomsOpg momsOpg : fakturaRes) {

				// toObjectArray returnere et object array, hvilket blive gemt i data[].
				dataFak[m] = momsOpg.toObjectArray4();
				m++;
			}
			










			ArrayList<MomsOpg> resultKoebsMoms = MomsSQL.koebsMoms();


			Object[] header2 = {"indg�ende moms (k�bsmoms) i alt"};
			
			
			//Opretter et todimentionelt array (kaldet data) af Object
			Object[][] dataSum = new Object[resultKoebsMoms.size()][1];
		

			//Looper igennem hvert element i results ArrayListen  
			int j=0;
			for (MomsOpg momsOpg : resultKoebsMoms) {

				// toObjectArray returnere et object array, hvilket blive gemt i data[].
				dataSum[j] = momsOpg.toObjectArray2();

				j++;
			}


			
			
			
			
			ArrayList<MomsOpg> resultSalgsMoms = MomsSQL.salgsMoms();


			Object[] header3 = {"Udg�ende moms (salgsmoms) i alt"};
			
			
			//Opretter et todimentionelt array (kaldet data) af Object
			Object[][] dataSum2 = new Object[resultSalgsMoms.size()][1];
		

			//Looper igennem hvert element i results ArrayListen  
			int k=0;
			for (MomsOpg momsOpg : resultSalgsMoms) {

				// toObjectArray returnere et object array, hvilket blive gemt i data[].
				dataSum2[k] = momsOpg.toObjectArray3();

				k++;
			}
			
			

			
			


			
			






//			// Opretter en DefaultTableModel, og inds�tter b�de data og header
			DefaultTableModel model = new DefaultTableModel(data, header);
			model.setColumnIdentifiers(header);
			table.setModel(model);



//			 Opretter en DefaultTableModel, og inds�tter b�de data og header
			DefaultTableModel modelKoebsMomsSum = new DefaultTableModel(dataSum, header2);
			modelKoebsMomsSum.setColumnIdentifiers(header2);
			table2.setModel(modelKoebsMomsSum);

			

//			 Opretter en DefaultTableModel, og inds�tter b�de data og header
			DefaultTableModel modelSalgsMoms = new DefaultTableModel(dataSum2, header3);
			modelSalgsMoms.setColumnIdentifiers(header3);
			table3.setModel(modelSalgsMoms);
			
			
			

//			 Opretter en DefaultTableModel, og inds�tter b�de data og header
			DefaultTableModel modelFakt = new DefaultTableModel(dataFak, header4);
			modelFakt.setColumnIdentifiers(header4);
			table4.setModel(modelFakt);
//			


		


		} catch (SQLException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
	


		// Opretter btnGem
		final JButton btnGem = new JButton("Gem");
		btnGem.setBounds(460, 401, 117, 29);
		mainframe.getContentPane().add(btnGem);

		//		// Funktionaliteten i gem knappen tilf�jes
		//		btnGem.addActionListener(new ActionListener(){
		//			public void actionPerformed(ActionEvent e) {
		//				
		//				// indstiller tabellen.
		//				TableModel model = table.getModel();
		//				int rows = model.getRowCount();
		//				
		//			    /* mens der stadig er flere r�kker, tager den v�rdien af den enkelte r�kke
		//			     og sender informationerne til MedlemSQL.updateSpiller() og StatistikSQL.updateStatistik()
		//				 som sender til DB for at opdatere medlemmet/spillleren */
		//				for (int i = 0 ; i<rows; i++) {
		//				int idSpiller = (int) model.getValueAt(i, 0);
		//				String fname = (String) model.getValueAt(i, 1);
		//				String ename = (String) model.getValueAt(i, 2);
		//								
		//				MedlemSQL.updateSpiller(idSpiller, fname, ename);
		//								
		//				int mål = Integer.parseInt(""+model.getValueAt(i, 3));
		//				int r�dt_kort = Integer.parseInt(""+ model.getValueAt(i, 4));
		//				int gult_kort = Integer.parseInt(""+model.getValueAt(i, 5));
		//								
		//				StatistikSQL.updateStatistik(idSpiller, mål, r�dt_kort, gult_kort);
		//				}
		//			}
		//		});

		// opretter btnTilbage, som hvis klikkes vil lukke vinudet ned (usynlig�rer den)
		JButton btnTilbage = new JButton("Tilbage");
		btnTilbage.setBounds(12, 403, 97, 25);
		mainframe.getContentPane().add(btnTilbage);
		
		JLabel lblGrundlagForKbsmoms = new JLabel("Grundlag for k\u00F8bsmoms");
		lblGrundlagForKbsmoms.setFont(new Font("Tahoma", Font.ITALIC, 28));
		lblGrundlagForKbsmoms.setBounds(262, 494, 297, 34);
		mainframe.getContentPane().add(lblGrundlagForKbsmoms);
		
		JLabel lblSalgsMoms = new JLabel("Grundlag for salgsmoms");
		lblSalgsMoms.setFont(new Font("Tahoma", Font.ITALIC, 28));
		lblSalgsMoms.setBounds(262, 734, 444, 34);
		mainframe.getContentPane().add(lblSalgsMoms);
		
		
		btnTilbage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.setVisible(false);
			}
		});

	}
}
