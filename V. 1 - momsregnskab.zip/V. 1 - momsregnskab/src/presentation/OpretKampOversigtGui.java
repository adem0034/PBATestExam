/*
 * Pop up Gui som g�r det muligt at oprette en ny kamp statistik. 
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import dlayer.OpretKampOversigtSQL;

public class OpretKampOversigtGui {
	
	// fields
	private static JTextField txtFieldVundet;
	private static JTextField txtFieldUafgjort;
	private static JTextField txtFieldTabt;
	private static JTextField txtFieldTr�ning;
	private static JTextField txtFieldKamp;
	private static JTextField txtFieldDato;
	private static JTextField txtFieldModstander;
	
	// k�rer metode
	 public OpretKampOversigtGui()
	 {
	  init();
	 }
	 
	 public static void init() 
	 {
		// Opretter en JFrame og  laver designet
		 final JFrame mainframe = new JFrame();
		 mainframe.setSize(330,490);
		 mainframe.setVisible(true);
		 mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		 mainframe.setLayout(null);
		 mainframe.setLocationRelativeTo(null);
		 
		 // Opretter en masse JLabels, s�tter st�rrelse og tilf�jer til mainframe.
		 JLabel lblVundet = new JLabel("Vundet");
		 lblVundet.setBounds(5, 10, 50, 16);
		 mainframe.add(lblVundet);

		 JLabel lblUafgjort = new JLabel("Uafgjort");
		 lblUafgjort.setBounds(5, 55, 60, 16);
		 mainframe.add(lblUafgjort);
	  
		 JLabel lblTabt = new JLabel("tabt");
		 lblTabt.setBounds(5, 100, 60, 16);
		 mainframe.add(lblTabt);
	  
		 JLabel lblTr�ning = new JLabel("træning");
		 lblTr�ning.setBounds(5, 142, 60, 16);
		 mainframe.add(lblTr�ning);
		  
		 JLabel lblKamp = new JLabel("Kamp");
		 lblKamp.setBounds(5, 190, 73, 16);
		 mainframe.getContentPane().add(lblKamp);
		 
		 JLabel lblDato = new JLabel("dato");
		 lblDato.setBounds(5, 230, 60, 16);
		 mainframe.add(lblDato);
		 
		 JLabel lblModstander = new JLabel("Modstander");
		 lblModstander.setBounds(5, 276, 98, 16);
		 mainframe.add(lblModstander);
			  
		  // opretter btnGemInfo
		 JButton btnGemInfo = new JButton("Gem");
		 btnGemInfo.setBounds(146, 403, 156, 29);
		 mainframe.add(btnGemInfo);
		  
		 // opretter en masse JTextfields, s�tter st�rrelse og tilf�jer til mainframe.
		 txtFieldVundet = new JTextField();
		 txtFieldVundet.setBounds(168, 4, 134, 28);
		 mainframe.add(txtFieldVundet);
		 txtFieldVundet.setColumns(10);
		  
		 txtFieldUafgjort = new JTextField();
		 txtFieldUafgjort.setBounds(168, 49, 134, 28);
		 mainframe.add(txtFieldUafgjort);
		 txtFieldUafgjort.setColumns(10);
		 
		 txtFieldTabt = new JTextField();
		 txtFieldTabt.setBounds(168, 94, 134, 28);
		 mainframe.add(txtFieldTabt);
		 txtFieldTabt.setColumns(10);
		 
		 txtFieldTr�ning = new JTextField();
		 txtFieldTr�ning.setBounds(168, 136, 134, 28);
		 mainframe.add(txtFieldTr�ning);
		 txtFieldTr�ning.setColumns(10);
		 
		 txtFieldKamp = new JTextField();
		 txtFieldKamp.setBounds(168, 184, 134, 28);
		 mainframe.add(txtFieldKamp);
		 txtFieldKamp.setColumns(10);
		  
		 txtFieldDato = new JTextField();
		 txtFieldDato.setBounds(168, 224, 134, 28);
		 mainframe.add(txtFieldDato);
		 txtFieldDato.setColumns(10);
		 
		 txtFieldModstander = new JTextField();
		 txtFieldModstander.setBounds(168, 270, 134, 28);
		 mainframe.add(txtFieldModstander);
		 txtFieldModstander.setColumns(10);

		 final JButton btnTilbage = new JButton("Tilbage");
		 btnTilbage.setBounds(5, 403, 117, 29);
		 mainframe.getContentPane().add(btnTilbage);
		
		 btnTilbage.addActionListener(new ActionListener(){
			 public void actionPerformed(ActionEvent e) {
			 btnTilbage.setVisible(true);
			 mainframe.setVisible(false); 
			 } 
		  });
	 
		 // Tilf�jer funktionalitet til btnGemInfo (gemmer statistik til DB)
		 btnGemInfo.addActionListener(new ActionListener() {
		 public void actionPerformed(ActionEvent arg0) {
			 
			 // Tager informationer fra txtFields og sender til OpretKampOversigtSQL.addKampOversigt, 
			 // som sender til DB.
			 int vundet = Integer.parseInt((String)txtFieldVundet.getText());
			 int uafgjort = Integer.parseInt((String)txtFieldUafgjort.getText());
			 int tabt = Integer.parseInt((String)txtFieldTabt.getText());
			 int tr�ning = Integer.parseInt((String)txtFieldTr�ning.getText());
			 int kamp = Integer.parseInt((String)txtFieldKamp.getText());
			 String dato = txtFieldDato.getText();
			 String modstander = txtFieldModstander.getText();
			 try {
				 // informationen er delt op i 2 forskellige tabeller. 
				 OpretKampOversigtSQL.addKampOversigt2(tr�ning, kamp, dato, modstander);
	        	 OpretKampOversigtSQL.addKampOversigt1(vundet, uafgjort, tabt);
	        	 } catch (SQLException e) {
	        		 // TODO Auto-generated catch block
	        		 e.printStackTrace();
	        		 }
			 // bekr�fter, at info er gemt + disposer vinduet.
			 JOptionPane.showMessageDialog(null, "Statistikken med datoen " + dato +  " er oprettet i Databasen");
		     mainframe.dispose();
		     }
		  });
	  }
}