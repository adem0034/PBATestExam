/*
 * Pop up Gui som g�r det muligt at oprette et nyt medlem/spiller. 
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import dlayer.MedlemSQL;

public class OpretMedlemGui 
{
	 // fields
 private static JTextField textField;
 private static JTextField textField_1;
 private static JTextField textField_2;
 private static JTextField textField_3;
 private static JTextField textField_4;
 private static JTextField textField_5;
 private static JTextField textField_6;
 private static JTextField textField_7;
 private static JTextField textField_8;
 
 
 public OpretMedlemGui()
 {
  init();
 }
 
 public static void init() 
 {
	// Opretter en JFrame og  laver designet
	 final JFrame mainframe = new JFrame();
	 mainframe.setSize(330,515);
	 mainframe.setVisible(true);
	 mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	 mainframe.getContentPane().setLayout(null);
	 mainframe.setLocationRelativeTo(null);
	  
	// Opretter en masse JLabels, s�tter st�rrelse og tilf�jer til mainframe.
	 JLabel lblFornavn = new JLabel("Fornavn");
	 lblFornavn.setBounds(5, 10, 50, 16);
	 mainframe.getContentPane().add(lblFornavn);
	 
	 JLabel lblEfternavn = new JLabel("Efternavn");
	 lblEfternavn.setBounds(5, 55, 60, 16);
	 mainframe.getContentPane().add(lblEfternavn);
	 
	 JLabel lblCpr = new JLabel("CPR");
	 lblCpr.setBounds(5, 100, 60, 16);
	 mainframe.getContentPane().add(lblCpr);
	 
	 JLabel lblEmail = new JLabel("Email");
	 lblEmail.setBounds(5, 142, 60, 16);
	 mainframe.getContentPane().add(lblEmail);
	 
	 JLabel lblTlf = new JLabel("Tlf");
	 lblTlf.setBounds(5, 190, 20, 16);
	 mainframe.getContentPane().add(lblTlf);
	 
	 JLabel lblBen = new JLabel("Ben");
	 lblBen.setBounds(5, 230, 60, 16);
	 mainframe.getContentPane().add(lblBen);
	 
	 JLabel lblTjstrrelse = new JLabel("Toejstoerrelse");
	 lblTjstrrelse.setBounds(5, 276, 98, 16);
	 mainframe.getContentPane().add(lblTjstrrelse);
	  
	 JLabel lblLand = new JLabel("Land");
	 lblLand.setBounds(4, 360, 61, 16);
	 mainframe.getContentPane().add(lblLand);
	 
	 JLabel lblIdHold = new JLabel("HoldNr");
	 lblIdHold.setBounds(5, 325, 61, 16);
	 mainframe.getContentPane().add(lblIdHold);
	  
	 // opretter en btnGemSpiller
	 JButton btnGemSpiller = new JButton("Gem spiller");
	 btnGemSpiller.setBounds(185, 426, 117, 29);
	 mainframe.getContentPane().add(btnGemSpiller);
  
	 // opretter en masse JTextfields, s�tter st�rrelse og tilf�jer til mainframe.
	 textField = new JTextField();
	 textField.setBounds(168, 4, 134, 28);
	 mainframe.getContentPane().add(textField);
	 textField.setColumns(10);
	  
	 textField_1 = new JTextField();
	 textField_1.setBounds(168, 49, 134, 28);
	 mainframe.getContentPane().add(textField_1);
	 textField_1.setColumns(10);
	 
	 textField_2 = new JTextField();
	 textField_2.setBounds(168, 94, 134, 28);
	 mainframe.getContentPane().add(textField_2);
	 textField_2.setColumns(10);
	 
	 textField_3 = new JTextField();
	 textField_3.setBounds(168, 136, 134, 28);
	 mainframe.getContentPane().add(textField_3);
	 textField_3.setColumns(10);
	 
	 textField_4 = new JTextField();
	 textField_4.setBounds(168, 184, 134, 28);
	 mainframe.getContentPane().add(textField_4);
	 textField_4.setColumns(10);
	 
	 textField_5 = new JTextField();
	 textField_5.setBounds(168, 224, 134, 28);
	 mainframe.getContentPane().add(textField_5);
	 textField_5.setColumns(10);
	 
	 textField_6 = new JTextField();
	 textField_6.setBounds(168, 270, 134, 28);
	 mainframe.getContentPane().add(textField_6);
	 textField_6.setColumns(10);
	 
	 textField_7 = new JTextField();
	 textField_7.setBounds(168, 319, 134, 28);
	 mainframe.getContentPane().add(textField_7);
	 textField_7.setColumns(10);
	 
	 textField_8 = new JTextField();
	 textField_8.setBounds(168, 354, 134, 28);
	 mainframe.getContentPane().add(textField_8);
	 textField_8.setColumns(10);
	
	 // Tilf�jer funktionalitet til btnGemInfo (oprette medlem i DB)
	 btnGemSpiller.addActionListener(new ActionListener() {
		 public void actionPerformed(ActionEvent arg0) { 
			 
			 
			 // Tager informationer fra txtFields og sender til MedlemSQL.addSpiller, 
			 // som sender til DB.			 
			 String fornavn = textField.getText();
			 String efternavn = textField_1.getText();
			 int cpr = Integer.parseInt((String)textField_2.getText());
			 String email = textField_3.getText();
			 int tlf = Integer.parseInt((String)textField_4.getText());
			 String ben = textField_5.getText();
			 String toejstoerrelse = textField_6.getText();
			 int idhold = Integer.parseInt((String)textField_7.getText());
			 String land = textField_8.getText();
			 
			 try {
				 // her sender/videregiver den variablerne til .addSpiller
				 MedlemSQL.addSpiller(fornavn, efternavn, cpr, email, tlf, ben);
				 } catch (SQLException e) {
					 // TODO Auto-generated catch block
					 e.printStackTrace();
					 }
			 // printer bekr�ftelse og disposer mainframe'en.
			 JOptionPane.showMessageDialog(null, "Medlemmet " + fornavn + " " + efternavn + " er oprettet i Databasen");
			 mainframe.dispose(); 
			 }
		 });
	 
	 // Opretter btnTilbage
	 final JButton btnTilbage = new JButton("Tilbage");
	 btnTilbage.setBounds(5, 426, 117, 29);
	 mainframe.getContentPane().add(btnTilbage);
	
	 // usynlig�r mainframe ved tryk p� Tilbage
	 btnTilbage.addActionListener(new ActionListener(){
		 public void actionPerformed(ActionEvent e) {
	     mainframe.setVisible(false);
	     }
		 });
	 }
}