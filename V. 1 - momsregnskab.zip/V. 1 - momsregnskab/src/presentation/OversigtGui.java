/*
 * Gui som viser en tabel oversigt over kampe (kampstatistik)
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Oversigt;
import dlayer.OversigtSQL;

public class OversigtGui {
	
	// fields
	private static JTable table;
	private static JFrame mainframe;

	 public OversigtGui()
	 {
	  init();
	 }
	 
	 
	public static void init() 
	 {
		// Opretter en JFrame og  laver designet	
		mainframe = new JFrame("GJKFK");
		mainframe.setSize(630,490);
		mainframe.setVisible(true);
		mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainframe.getContentPane().setLayout(null);
		mainframe.setLocationRelativeTo(null);
		
		
		try {
			// tilf�jer en scroll funktion
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(22, 75, 565, 296);
			mainframe.add(scrollPane);
			
			// opretter table
			table = new JTable();
			scrollPane.setViewportView(table);
			table.setVisible(true);

			 
			/* Kalder OversigtSQL.info() og s�tter v�rdien til at v�re en ArrayList
			af typen Oversigt.*/
			ArrayList<Oversigt> results = OversigtSQL.Info();
			
			// Opretter object der navngives "header" og giver den parametre. 
			Object[] header = {"dato", "vundet", "uafgjort", "tabt", "modstander"};

			//Opretter et todimentionelt array (kaldet data) af Object
			Object[][] data = new Object[results.size()][5];
			
			//Looper igennem hvert element i results ArrayListen  
			int i=0;
			for (Oversigt oversigt: results) {
				
				// toObjectArray returnere et object array, hvilket blive gemt i data[].
				data[i] = oversigt.toObjectArray();
				i++;
			}
			  // Opretter en DefaultTableModel, og inds�tter b�de data og header
			DefaultTableModel model = new DefaultTableModel(data, header);
			model.setColumnIdentifiers(header);
			table.setModel(model);
			
			// Opretter btntilf�jKampInfo, og kalder deri OpretKampOversigtGuis metode
			JButton btnTilfjKampInfo = new JButton("Tilf\u00F8j kamp info");
			btnTilfjKampInfo.setBounds(466, 388, 121, 25);
			mainframe.getContentPane().add(btnTilfjKampInfo);
			btnTilfjKampInfo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					OpretKampOversigtGui.init();
				}
			});
		} catch (SQLException h) {
			// TODO Auto-generated catch block
			h.printStackTrace();
		}
		
		// opretter btntilbage
		final JButton btnTilbage = new JButton("Tilbage");
		btnTilbage.setBounds(6, 384, 117, 29);
		mainframe.getContentPane().add(btnTilbage);
		
		// g�r btnmainframe usynlig / lukker ned ved tryk p� tilbage
	    btnTilbage.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e) {
		    mainframe.setVisible(false);
		   }
		  });
	}
}
