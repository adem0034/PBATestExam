/*
 * Medlem der indeholder de 3 undermetoders knapper (opret,oversigt,slet)
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;

import dlayer.MedlemSQL;
import dlayer.RegningSQL;

public class RegningGUI {
	private static JTextField txtLeverandr;
	private static JTextField txtValuta;
	private static JTextField txtPriseksmoms;
	private static JTextField txtRegningsdag;
	private static JTextField txtPrisinkmoms;

	public RegningGUI()
	{
		init();
	}

	public static void init() 
	{
		// Opretter en JFrame og  laver designet
		final JFrame mainframe = new JFrame("GJKFK");
		mainframe.setSize(630,536);
		mainframe.setVisible(true);
		mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainframe.getContentPane().setLayout(null);
		mainframe.setLocationRelativeTo(null);

		// Opretter btnTilbage og lukker vinduet ned.
		JButton btnTilbage = new JButton("Tilbage");
		btnTilbage.setBounds(12, 447, 97, 29);
		mainframe.getContentPane().add(btnTilbage);

		JComboBox comboBox = new JComboBox();
		comboBox.addItem("Sm�anskaffelser  - 25%");
		comboBox.addItem("Diverse udgifter - 25%");
		comboBox.addItem("IT (computere osv.) - 25%");
		comboBox.addItem("Kontorartikler - 25%");
		comboBox.addItem("K�rselsgodtg�relse - 25%");
		comboBox.addItem("Reklamer og markedsf�ring - 25%");
		comboBox.addItem("Restaurant - 25%");
		comboBox.addItem("Transport og rejser  - 25%");
		comboBox.addItem("Website - 25%");
		comboBox.addItem("Kontant - 25%");


		comboBox.setBounds(255, 32, 331, 22);
		mainframe.getContentPane().add(comboBox);

		JLabel lblKategori = new JLabel("kategori");
		lblKategori.setBounds(12, 35, 87, 16);
		mainframe.getContentPane().add(lblKategori);

		JLabel lblBetaltikkeBetalt = new JLabel("betalt/ikke betalt");
		lblBetaltikkeBetalt.setBounds(12, 139, 95, 16);
		mainframe.getContentPane().add(lblBetaltikkeBetalt);

		JCheckBox chckbxBetalt = new JCheckBox("Betalt");
		chckbxBetalt.setBounds(255, 135, 113, 25);
		mainframe.getContentPane().add(chckbxBetalt);

		JLabel lblLeverandr = new JLabel("Leverand\u00F8r");
		lblLeverandr.setBounds(12, 172, 97, 16);
		mainframe.getContentPane().add(lblLeverandr);

		txtLeverandr = new JTextField();
		txtLeverandr.setText("Leverand\u00F8r");
		txtLeverandr.setBounds(241, 169, 116, 22);
		mainframe.getContentPane().add(txtLeverandr);
		txtLeverandr.setColumns(10);

		JLabel lblValuta = new JLabel("Valuta");
		lblValuta.setBounds(12, 241, 56, 16);
		mainframe.getContentPane().add(lblValuta);

		txtValuta = new JTextField();
		txtValuta.setText("valuta");
		txtValuta.setBounds(241, 245, 116, 22);
		mainframe.getContentPane().add(txtValuta);
		txtValuta.setColumns(10);

		JLabel lblBeskrivelse = new JLabel("Beskrivelse");
		lblBeskrivelse.setBounds(12, 297, 128, 16);
		mainframe.getContentPane().add(lblBeskrivelse);

		JTextPane txtpnBeskrivelse = new JTextPane();
		txtpnBeskrivelse.setText("beskrivelse");
		txtpnBeskrivelse.setBounds(241, 280, 164, 60);
		mainframe.getContentPane().add(txtpnBeskrivelse);

		txtPriseksmoms = new JTextField();
		txtPriseksmoms.setText("prisEksMoms");
		txtPriseksmoms.setBounds(241, 353, 116, 22);
		mainframe.getContentPane().add(txtPriseksmoms);
		txtPriseksmoms.setColumns(10);

		JLabel lblPriseksmoms = new JLabel("prisEksMoms");
		lblPriseksmoms.setBounds(12, 356, 128, 16);
		mainframe.getContentPane().add(lblPriseksmoms);

		JLabel lblUploadBilag = new JLabel("Upload bilag:");
		lblUploadBilag.setBounds(378, 407, 113, 16);
		mainframe.getContentPane().add(lblUploadBilag);

		JButton btnGemRegning = new JButton("Gem Regning");
		btnGemRegning.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				//    		 SQL stuff here .... 
			
				String supplier = txtLeverandr.getText();
				String category = (String) comboBox.getSelectedItem();
				String date = txtRegningsdag.getText();
				boolean paid = chckbxBetalt.isSelected();
				String descript = txtpnBeskrivelse.getText();
				String valuta = txtValuta.getText();
				int priceNoVat = Integer.parseInt(txtPriseksmoms.getText());
				int priceVat = Integer.parseInt(txtPrisinkmoms.getText());
				

				 try {
					 // her sender/videregiver den variablerne til .addSpiller
					 RegningSQL.addRegning(supplier, category, date, paid, descript, valuta, priceNoVat, priceVat);
					 } catch (SQLException e) {
						 // TODO Auto-generated catch block
						 e.printStackTrace();
						 }
				 // printer bekr�ftelse og disposer mainframe'en.
				 JOptionPane.showMessageDialog(null, "Regningen fra  " + supplier + " " +" er oprettet i Databasen");
				 mainframe.dispose(); 

				
			}
		});
		btnGemRegning.setBounds(345, 449, 177, 25);
		mainframe.getContentPane().add(btnGemRegning);
		
		JLabel lblRegningsdag = new JLabel("Regningsdag");
		lblRegningsdag.setBounds(12, 110, 104, 16);
		mainframe.getContentPane().add(lblRegningsdag);
		
		txtRegningsdag = new JTextField();
		txtRegningsdag.setText("regningsdag");
		txtRegningsdag.setBounds(241, 104, 116, 22);
		mainframe.getContentPane().add(txtRegningsdag);
		txtRegningsdag.setColumns(10);
		
		JLabel lblPrisinkmoms = new JLabel("prisInkMoms");
		lblPrisinkmoms.setBounds(12, 407, 97, 16);
		mainframe.getContentPane().add(lblPrisinkmoms);
		
		txtPrisinkmoms = new JTextField();
		txtPrisinkmoms.setText("prisInkMoms");
		txtPrisinkmoms.setBounds(241, 404, 116, 22);
		mainframe.getContentPane().add(txtPrisinkmoms);
		txtPrisinkmoms.setColumns(10);






		//    System.out.println(chckbxBetalt.isSelected());

		btnTilbage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainframe.setVisible(false);
			}
		});




	}
}