/*
 * Gui, som g�r det muligt at s�ge efter spiller/medlem
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.SoegFunktion;
import dlayer.SoegFunktionSQL;

public class SoegFunktionGui {
	private static JTable table;
	public SoegFunktionGui() {

		init();
		}
	public static void init() {
		// Opretter en JFrame og  laver designet
		final JFrame mainframe = new JFrame("GJKFK");
		mainframe.setSize(630,490);
		mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainframe.setLayout(null);
		mainframe.setLocationRelativeTo(null);
		
		try {
			// tilf�jer en "scroll" funktion 
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(22, 75, 565, 296);
			mainframe.getContentPane().add(scrollPane);
			
			// opretter en jTable og s�tter scrollPane sammen
			table = new JTable();
			scrollPane.setViewportView(table);
			table.setVisible(true);
			
			// ArrayList "results" af typen SoegFunktion 
			ArrayList<SoegFunktion> results;
			
			  // Returnerer ArrayList af typen SoegFunktion
			results = SoegFunktionSQL.soegInfo();
				
			// Opretter object der navngives "header" og giver den parametre. 
			Object[] header = {"ID", "Fornavn", "Efternavn", "Mål", "Rødt kort", "Gult kort"};
			
			  //Opretter et todimentionelt array (kaldet data) af Object
			Object[][] data = new Object[results.size()][6];
			
			  //Looper igennem hvert element i results ArrayListen
			int j=0;
			for (SoegFunktion s�g : results) {
			
				 // toObjectArray returnere et object array, hvilket blive gemt i data[].
			data[j] = s�g.toObjectArray();
			j++;
			}
			
			 // Opretter en DefaultTableModel, og inds�tter b�de data og header
			DefaultTableModel model = new DefaultTableModel(data, header);
			model.setColumnIdentifiers(header);
			table.setModel(model);
			
			// Opretter en btnTilbage
			final JButton btnTilbage = new JButton("Tilbage");
			btnTilbage.setBounds(6, 384, 117, 29);
			mainframe.getContentPane().add(btnTilbage);
					
			// g�r mainframe usynlig / lukker ned ved tryk p� tilbage
			btnTilbage.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
				mainframe.setVisible(false);
				}
				});
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  mainframe.setVisible(true);
	}
}