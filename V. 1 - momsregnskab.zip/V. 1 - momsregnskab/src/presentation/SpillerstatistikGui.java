/*
 * Gui der viser tabel over spillerstatisik - og som g�r det muligt, at �ndre info i tabellen
 */
package presentation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import model.Statistik;
import dlayer.MedlemSQL;
import dlayer.StatistikSQL;

public class SpillerstatistikGui {
	public SpillerstatistikGui() {
		init();
	}
	
	//field
	private static JTable table; 
	
	public static void init() {
		// Opretter en JFrame og  laver designet
		final JFrame mainframe = new JFrame("GJKFK");
		mainframe.setSize(630,490);
		mainframe.setVisible(true);
		mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainframe.getContentPane().setLayout(null);
		mainframe.setLocationRelativeTo(null);
		
		try {
			// tilf�jer en "scroll" funktion 
			JScrollPane scrollPane = new JScrollPane();
			scrollPane.setBounds(12, 74, 565, 296);
			mainframe.getContentPane().add(scrollPane);
			
			// opretter en jTable og s�tter scrollPane sammen
			table = new JTable();
			scrollPane.setViewportView(table);
			table.setVisible(true);
						
			/* Kalder StatistikSQL. statistik() og s�tter v�rdien til at v�re en ArrayList
			af typen Statistik.*/
			ArrayList<Statistik> results = StatistikSQL.statistik();
						
			// Opretter object der navngives "header" og giver den parametre. 
			Object[] header = {"ID","Fornavn", "Efternavn", "Mål", "Rødt Kort", "Gult Kort"};
						
			//Opretter et todimentionelt array (kaldet data) af Object
			Object[][] data = new Object[results.size()][6];
						
			//Looper igennem hvert element i results ArrayListen  
			int i=0;
			for (Statistik statistik : results) {
				
				// toObjectArray returnere et object array, hvilket blive gemt i data[].
				data[i] = statistik.toObjectArray();
				i++;
				}
			
			// Opretter en DefaultTableModel, og inds�tter b�de data og header
			DefaultTableModel model = new DefaultTableModel(data, header);
			model.setColumnIdentifiers(header);
			table.setModel(model);
							
			} catch (SQLException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
				}

		// Opretter btnGem
		final JButton btnGem = new JButton("Gem");
		btnGem.setBounds(460, 401, 117, 29);
		mainframe.add(btnGem);
		
		// Funktionaliteten i gem knappen tilf�jes
		btnGem.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				
				// indstiller tabellen.
				TableModel model = table.getModel();
				int rows = model.getRowCount();
				
			    /* mens der stadig er flere r�kker, tager den v�rdien af den enkelte r�kke
			     og sender informationerne til MedlemSQL.updateSpiller() og StatistikSQL.updateStatistik()
				 som sender til DB for at opdatere medlemmet/spillleren */
				for (int i = 0 ; i<rows; i++) {
				int idSpiller = (int) model.getValueAt(i, 0);
				String fname = (String) model.getValueAt(i, 1);
				String ename = (String) model.getValueAt(i, 2);
								
				MedlemSQL.updateSpiller(idSpiller, fname, ename);
								
				int mål = Integer.parseInt(""+model.getValueAt(i, 3));
				int r�dt_kort = Integer.parseInt(""+ model.getValueAt(i, 4));
				int gult_kort = Integer.parseInt(""+model.getValueAt(i, 5));
								
				StatistikSQL.updateStatistik(idSpiller, mål, r�dt_kort, gult_kort);
				}
			}
		});
			
			// opretter btnTilbage, som hvis klikkes vil lukke vinudet ned (usynlig�rer den)
			JButton btnTilbage = new JButton("Tilbage");
			btnTilbage.setBounds(12, 403, 97, 25);
			mainframe.add(btnTilbage);
			btnTilbage.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mainframe.setVisible(false);
					}
			});
			
	}
}