/*
 * Gui som indeholder underpunkterne S�g, Oversigt og Spillerstatistik 
 */
package presentation;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;


public class StatistikGui {
	
	public StatistikGui() {
		init();
	 }
	public static void init() {
		
		// Opretter en JFrame og  laver designet
		final JFrame mainframe = new JFrame("GJKFK");
		mainframe.setSize(630,490);
		mainframe.setVisible(true);
		mainframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		mainframe.getContentPane().setLayout(null);
		mainframe.setLocationRelativeTo(null);
		
		// Opretter btnSg og k�rer SoegFunktionGui.init() metoden
		JButton btnSg = new JButton("Soeg");
		btnSg.setBounds(111, 6, 117, 29);
		mainframe.add(btnSg);
		btnSg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SoegFunktionGui.init();
		}
	});
		// Opretter btnOversigt og k�rer OversigtGui.init metoden
		JButton btnOversigt = new JButton("Oversigt");
		btnOversigt.setBounds(273, 6, 117, 29);
		mainframe.getContentPane().add(btnOversigt);
		btnOversigt.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			OversigtGui.init();
		}
	});
			// Opretter btnSpillerstatistik og k�rer init() metoden.
		JButton btnSpillerstatistik = new JButton("Spillerstatistik");
		btnSpillerstatistik.setBounds(436, 8, 117, 29);
		mainframe.getContentPane().add(btnSpillerstatistik);
		btnSpillerstatistik.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				SpillerstatistikGui.init();
		}
	});
	
			// opretter btnTilbage, som lukker vinduet ned
		final JButton btnTilbage = new JButton("Tilbage");
		btnTilbage.setBounds(6, 384, 117, 29);
		mainframe.add(btnTilbage);
		btnTilbage.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e) {
		    mainframe.setVisible(false);
		    }
			});
		}
}
