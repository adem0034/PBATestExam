package presentation;

import java.sql.SQLException;
import static org.junit.Assert.*;

import org.junit.Test;

public class GuiMainJUNIT {

	@Test
	public void test() throws SQLException {
		
		PhoneOrder order = new PhoneOrder();
		
		
		
		
		
	}

}
